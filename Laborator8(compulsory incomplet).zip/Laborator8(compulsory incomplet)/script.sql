CREATE TABLE movies(
	id INT PRIMARY KEY,
	title VARCHAR(20),
	relase_date DATE,
	duration INT,
	score FLOAT
);

CREATE TABLE genres(
	id INT PRIMARY KEY,
	name VARCHAR(20)
);